import { Button } from "@/components/ui/button"
import { ArrowLeft, CheckCircle2 } from "lucide-react"

const benefits = [
  "وصول غير محدود لجميع المقالات",
  "تنبيهات فورية للوظائف الجديدة",
  "استخدام جميع التطبيقات المحاسبية",
  "دعم فني على مدار الساعة",
]

export function CTASection() {
  return (
    <section className="relative overflow-hidden bg-primary py-20 lg:py-28">
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
      </div>

      <div className="container mx-auto px-4 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="mb-6 text-3xl font-bold text-primary-foreground sm:text-4xl text-balance">
            انضم إلى أكثر من 10,000 محاسب عربي
          </h2>
          <p className="mb-8 text-lg text-primary-foreground/80 leading-relaxed">
            سجل الآن مجاناً واحصل على جميع المميزات التي تحتاجها لتطوير مسيرتك المهنية
          </p>

          {/* Benefits */}
          <div className="mb-10 flex flex-wrap justify-center gap-4">
            {benefits.map((benefit) => (
              <div
                key={benefit}
                className="flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-2 text-sm text-primary-foreground"
              >
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button 
              size="lg" 
              variant="secondary" 
              className="gap-2 bg-primary-foreground text-primary hover:bg-primary-foreground/90 w-full sm:w-auto"
            >
              إنشاء حساب مجاني
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 w-full sm:w-auto"
            >
              تعرف على المزيد
            </Button>
          </div>

          <p className="mt-6 text-sm text-primary-foreground/60">
            لا حاجة لبطاقة ائتمان • إلغاء في أي وقت
          </p>
        </div>
      </div>
    </section>
  )
}

import Link from "next/link"
import { Calculator, Mail, Phone, MapPin } from "lucide-react"

const footerLinks = {
  platform: [
    { name: "المقالات المحاسبية", href: "/articles" },
    { name: "الوظائف المحاسبية", href: "/jobs" },
    { name: "التطبيقات المحاسبية", href: "/tools" },
    { name: "الدورات التدريبية", href: "#" },
  ],
  resources: [
    { name: "المعايير المحاسبية", href: "#" },
    { name: "القوانين الضريبية", href: "#" },
    { name: "النماذج والقوالب", href: "#" },
    { name: "الأسئلة الشائعة", href: "#" },
  ],
  company: [
    { name: "من نحن", href: "#" },
    { name: "تواصل معنا", href: "#" },
    { name: "سياسة الخصوصية", href: "#" },
    { name: "الشروط والأحكام", href: "#" },
  ],
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="container mx-auto px-4 py-12 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Calculator className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">محاسبون</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              منصة متكاملة تخدم المحاسبين العرب من خلال توفير المقالات العلمية، 
              فرص العمل، والأدوات المحاسبية الاحترافية.
            </p>
            <div className="flex flex-col gap-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>info@mohaseboon.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span dir="ltr">+966 50 123 4567</span>
              </div>
            </div>
          </div>

          {/* Platform Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold">المنصة</h3>
            <ul className="space-y-3">
              {footerLinks.platform.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold">الموارد</h3>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold">الشركة</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} محاسبون. جميع الحقوق محفوظة.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                سياسة الخصوصية
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                الشروط والأحكام
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

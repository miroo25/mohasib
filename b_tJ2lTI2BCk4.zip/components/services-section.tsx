import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Briefcase, AppWindow, ArrowLeft, BookOpen, TrendingUp, Calculator } from "lucide-react"
import Link from "next/link"

const services = [
  {
    title: "المقالات المحاسبية",
    description: "مقالات متخصصة في المحاسبة المالية، محاسبة التكاليف، المراجعة، والمعايير الدولية",
    icon: FileText,
    href: "/articles",
    features: ["معايير IFRS", "محاسبة التكاليف", "المراجعة والتدقيق", "الضرائب"],
    color: "bg-primary/10 text-primary",
  },
  {
    title: "الوظائف المحاسبية",
    description: "فرص عمل حصرية للمحاسبين في الشركات الكبرى والمكاتب المحاسبية المعتمدة",
    icon: Briefcase,
    href: "/jobs",
    features: ["وظائف بدوام كامل", "عمل عن بعد", "تدريب تعاوني", "استشارات"],
    color: "bg-accent/10 text-accent",
  },
  {
    title: "التطبيقات المحاسبية",
    description: "أدوات وتطبيقات محاسبية تساعدك في إنجاز عملك بكفاءة ودقة عالية",
    icon: AppWindow,
    href: "/tools",
    features: ["حاسبة الضرائب", "جدول الإهلاك", "تحليل مالي", "قوالب Excel"],
    color: "bg-chart-3/20 text-chart-3",
  },
]

export function ServicesSection() {
  return (
    <section className="bg-muted/30 py-20 lg:py-28">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
            <BookOpen className="h-4 w-4" />
            خدماتنا
          </div>
          <h2 className="mb-4 text-3xl font-bold text-foreground sm:text-4xl text-balance">
            كل ما تحتاجه لتطوير مسيرتك المهنية
          </h2>
          <p className="text-muted-foreground text-pretty">
            نوفر لك مجموعة متكاملة من الخدمات والموارد التي تساعدك على التميز في مجال المحاسبة
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <Card 
              key={service.title} 
              className="group relative overflow-hidden border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-xl"
            >
              <CardHeader className="pb-4">
                <div className={`mb-4 flex h-14 w-14 items-center justify-center rounded-2xl ${service.color} transition-transform group-hover:scale-110`}>
                  <service.icon className="h-7 w-7" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription className="text-base leading-relaxed">
                  {service.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="mb-6 space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="flex h-1.5 w-1.5 rounded-full bg-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button variant="outline" className="w-full gap-2 group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary" asChild>
                  <Link href={service.href}>
                    استكشف المزيد
                    <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

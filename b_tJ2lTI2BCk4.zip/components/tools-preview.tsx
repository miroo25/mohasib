import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  Calculator, 
  FileSpreadsheet, 
  PieChart, 
  Receipt, 
  TrendingUp, 
  Percent,
  Building,
  CreditCard
} from "lucide-react"
import Link from "next/link"

const tools = [
  {
    id: 1,
    name: "حاسبة ضريبة القيمة المضافة",
    description: "احسب ضريبة القيمة المضافة بسهولة ودقة",
    icon: Percent,
    category: "ضرائب",
    href: "/tools/vat-calculator",
    popular: true,
  },
  {
    id: 2,
    name: "جدول الإهلاك",
    description: "إنشاء جداول إهلاك الأصول الثابتة",
    icon: TrendingUp,
    category: "أصول",
    href: "/tools/depreciation",
    popular: true,
  },
  {
    id: 3,
    name: "حاسبة نهاية الخدمة",
    description: "احسب مكافأة نهاية الخدمة حسب نظام العمل",
    icon: Receipt,
    category: "رواتب",
    href: "/tools/end-of-service",
    popular: false,
  },
  {
    id: 4,
    name: "تحليل النسب المالية",
    description: "تحليل شامل للنسب المالية للشركات",
    icon: PieChart,
    category: "تحليل",
    href: "/tools/financial-ratios",
    popular: true,
  },
  {
    id: 5,
    name: "حاسبة القروض",
    description: "احسب الأقساط الشهرية ومجموع الفوائد",
    icon: CreditCard,
    category: "قروض",
    href: "/tools/loan-calculator",
    popular: false,
  },
  {
    id: 6,
    name: "حاسبة الزكاة",
    description: "احسب زكاة المال والتجارة والأسهم",
    icon: Building,
    category: "زكاة",
    href: "/tools/zakat-calculator",
    popular: true,
  },
]

export function ToolsPreview() {
  return (
    <section className="py-20 lg:py-28">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="mb-12 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="mb-2 text-3xl font-bold text-foreground">التطبيقات المحاسبية</h2>
            <p className="text-muted-foreground">أدوات احترافية تساعدك في إنجاز عملك بكفاءة</p>
          </div>
          <Button variant="outline" className="gap-2" asChild>
            <Link href="/tools">
              جميع التطبيقات
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        {/* Tools Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tools.map((tool) => (
            <Link key={tool.id} href={tool.href}>
              <Card className="group h-full cursor-pointer border-border/50 transition-all hover:border-primary/30 hover:shadow-lg">
                <CardContent className="flex items-start gap-4 p-6">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <tool.icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="mb-1 flex items-center gap-2">
                      <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors truncate">
                        {tool.name}
                      </h3>
                      {tool.popular && (
                        <Badge variant="secondary" className="shrink-0 text-xs">
                          شائع
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {tool.description}
                    </p>
                    <Badge variant="outline" className="mt-2 text-xs">
                      {tool.category}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* View All CTA */}
        <div className="mt-12 rounded-2xl border border-border bg-muted/50 p-8 text-center">
          <h3 className="mb-2 text-xl font-semibold">هل تبحث عن أداة محددة؟</h3>
          <p className="mb-6 text-muted-foreground">
            لدينا أكثر من 25 أداة وتطبيق محاسبي لمساعدتك في عملك اليومي
          </p>
          <Button size="lg" className="gap-2" asChild>
            <Link href="/tools">
              تصفح جميع التطبيقات
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

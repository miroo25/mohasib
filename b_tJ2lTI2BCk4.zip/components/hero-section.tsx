import { Button } from "@/components/ui/button"
import { ArrowLeft, FileText, Briefcase, AppWindow, Users } from "lucide-react"
import Link from "next/link"

const stats = [
  { label: "مقال محاسبي", value: "500+", icon: FileText },
  { label: "وظيفة متاحة", value: "150+", icon: Briefcase },
  { label: "تطبيق محاسبي", value: "25+", icon: AppWindow },
  { label: "محاسب مسجل", value: "10K+", icon: Users },
]

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-background">
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:24px_24px]" />
        <div className="absolute right-0 top-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-primary/5 blur-[100px]" />
        <div className="absolute left-0 bottom-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-accent/5 blur-[100px]" />
      </div>

      <div className="container mx-auto px-4 py-20 lg:px-8 lg:py-32">
        <div className="mx-auto max-w-4xl text-center">
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-muted/50 px-4 py-1.5 text-sm">
            <span className="flex h-2 w-2 rounded-full bg-accent" />
            <span className="text-muted-foreground">منصة المحاسبين العرب الأولى</span>
          </div>

          {/* Heading */}
          <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
            كل ما يحتاجه{" "}
            <span className="text-primary">المحاسب العربي</span>{" "}
            في مكان واحد
          </h1>

          {/* Subtitle */}
          <p className="mx-auto mb-10 max-w-2xl text-lg text-muted-foreground leading-relaxed text-pretty">
            منصة متكاملة توفر المقالات المحاسبية المتخصصة، فرص العمل الحصرية، 
            والأدوات والتطبيقات المحاسبية التي تساعدك على التميز في مهنتك.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" className="gap-2 w-full sm:w-auto">
              ابدأ الآن مجاناً
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto">
              تصفح المقالات
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="mx-auto mt-20 max-w-4xl">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 text-center transition-all hover:border-primary/50 hover:shadow-lg"
              >
                <div className="mb-3 flex justify-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

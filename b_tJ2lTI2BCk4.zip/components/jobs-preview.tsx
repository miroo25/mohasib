import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, MapPin, Clock, Banknote, Building2 } from "lucide-react"
import Link from "next/link"

const jobs = [
  {
    id: 1,
    title: "محاسب أول",
    company: "شركة الراجحي للاستثمار",
    location: "الرياض، السعودية",
    type: "دوام كامل",
    salary: "15,000 - 20,000 ر.س",
    posted: "منذ يومين",
    urgent: true,
  },
  {
    id: 2,
    title: "مدير مالي",
    company: "مجموعة سابك",
    location: "جدة، السعودية",
    type: "دوام كامل",
    salary: "25,000 - 35,000 ر.س",
    posted: "منذ 3 أيام",
    urgent: false,
  },
  {
    id: 3,
    title: "محاسب تكاليف",
    company: "شركة المراعي",
    location: "الدمام، السعودية",
    type: "دوام كامل",
    salary: "12,000 - 16,000 ر.س",
    posted: "منذ أسبوع",
    urgent: false,
  },
  {
    id: 4,
    title: "مراجع داخلي",
    company: "بنك الإنماء",
    location: "الرياض، السعودية",
    type: "دوام كامل",
    salary: "18,000 - 22,000 ر.س",
    posted: "منذ 5 أيام",
    urgent: true,
  },
  {
    id: 5,
    title: "محاسب - عمل عن بعد",
    company: "شركة تقنية ناشئة",
    location: "عن بعد",
    type: "عن بعد",
    salary: "10,000 - 14,000 ر.س",
    posted: "منذ يوم",
    urgent: false,
  },
]

export function JobsPreview() {
  return (
    <section className="bg-muted/30 py-20 lg:py-28">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="mb-12 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="mb-2 text-3xl font-bold text-foreground">أحدث الوظائف</h2>
            <p className="text-muted-foreground">فرص عمل حصرية في أفضل الشركات والمؤسسات</p>
          </div>
          <Button variant="outline" className="gap-2" asChild>
            <Link href="/jobs">
              جميع الوظائف
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        {/* Jobs List */}
        <div className="space-y-4">
          {jobs.map((job) => (
            <Card 
              key={job.id} 
              className="group overflow-hidden border-border/50 transition-all hover:border-primary/30 hover:shadow-lg"
            >
              <CardContent className="p-6">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  {/* Job Info */}
                  <div className="flex-1">
                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                        {job.title}
                      </h3>
                      {job.urgent && (
                        <Badge variant="destructive" className="text-xs">
                          عاجل
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs">
                        {job.type}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        <span>{job.company}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Banknote className="h-4 w-4" />
                        <span>{job.salary}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{job.posted}</span>
                      </div>
                    </div>
                  </div>

                  {/* Apply Button */}
                  <Button className="shrink-0 gap-2">
                    تقدم الآن
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="mt-8 text-center">
          <Button variant="outline" size="lg" asChild>
            <Link href="/jobs">
              عرض جميع الوظائف ({150}+)
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Clock, User, Eye } from "lucide-react"
import Link from "next/link"

const articles = [
  {
    id: 1,
    title: "دليل شامل لمعايير المحاسبة الدولية IFRS 2024",
    description: "تعرف على أحدث التحديثات في معايير التقارير المالية الدولية وكيفية تطبيقها في شركتك",
    category: "معايير محاسبية",
    author: "د. أحمد محمد",
    readTime: "12 دقيقة",
    views: "2.5K",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=250&fit=crop",
    featured: true,
  },
  {
    id: 2,
    title: "كيفية إعداد القوائم المالية وفق المعايير السعودية",
    description: "خطوات عملية لإعداد قوائم مالية متوافقة مع متطلبات هيئة الزكاة والضريبة",
    category: "قوائم مالية",
    author: "أ. سارة العتيبي",
    readTime: "8 دقائق",
    views: "1.8K",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=250&fit=crop",
    featured: false,
  },
  {
    id: 3,
    title: "أساسيات محاسبة التكاليف للمبتدئين",
    description: "مقدمة شاملة في محاسبة التكاليف وطرق حساب تكلفة المنتجات والخدمات",
    category: "محاسبة التكاليف",
    author: "أ. خالد الشمري",
    readTime: "10 دقائق",
    views: "3.2K",
    image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=400&h=250&fit=crop",
    featured: false,
  },
  {
    id: 4,
    title: "التخطيط الضريبي للشركات الصغيرة والمتوسطة",
    description: "استراتيجيات فعالة لتقليل العبء الضريبي بطرق قانونية ومعتمدة",
    category: "الضرائب",
    author: "أ. منى الحربي",
    readTime: "15 دقيقة",
    views: "2.1K",
    image: "https://images.unsplash.com/photo-1554224155-3a58922a22c3?w=400&h=250&fit=crop",
    featured: false,
  },
]

export function ArticlesPreview() {
  return (
    <section className="py-20 lg:py-28">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Section Header */}
        <div className="mb-12 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h2 className="mb-2 text-3xl font-bold text-foreground">أحدث المقالات</h2>
            <p className="text-muted-foreground">مقالات متخصصة يكتبها خبراء في مجال المحاسبة والمراجعة</p>
          </div>
          <Button variant="outline" className="gap-2" asChild>
            <Link href="/articles">
              جميع المقالات
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        {/* Articles Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {articles.map((article, index) => (
            <Card 
              key={article.id} 
              className={`group overflow-hidden border-border/50 transition-all hover:border-primary/30 hover:shadow-lg ${
                index === 0 ? "md:col-span-2 md:row-span-2" : ""
              }`}
            >
              <div className={`relative overflow-hidden ${index === 0 ? "h-64" : "h-40"}`}>
                <img
                  src={article.image}
                  alt={article.title}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <Badge className="absolute top-3 right-3 bg-primary/90 hover:bg-primary">
                  {article.category}
                </Badge>
              </div>
              <CardHeader className={index === 0 ? "pb-2" : "p-4 pb-2"}>
                <CardTitle className={`line-clamp-2 ${index === 0 ? "text-xl" : "text-base"}`}>
                  {article.title}
                </CardTitle>
                {index === 0 && (
                  <CardDescription className="line-clamp-2 mt-2">
                    {article.description}
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent className={index === 0 ? "" : "p-4 pt-0"}>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    <span>{article.author}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>{article.readTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      <span>{article.views}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

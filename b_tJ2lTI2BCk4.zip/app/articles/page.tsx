import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Clock, User, Eye, Search, Filter, BookOpen } from "lucide-react"

const categories = [
  "الكل",
  "معايير محاسبية",
  "محاسبة التكاليف",
  "المراجعة والتدقيق",
  "الضرائب",
  "قوائم مالية",
  "تحليل مالي",
]

const articles = [
  {
    id: 1,
    title: "دليل شامل لمعايير المحاسبة الدولية IFRS 2024",
    description: "تعرف على أحدث التحديثات في معايير التقارير المالية الدولية وكيفية تطبيقها في شركتك. نستعرض في هذا المقال جميع التغييرات الجديدة وتأثيرها على القوائم المالية.",
    category: "معايير محاسبية",
    author: "د. أحمد محمد",
    readTime: "12 دقيقة",
    views: "2.5K",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&h=400&fit=crop",
    date: "15 مارس 2024",
  },
  {
    id: 2,
    title: "كيفية إعداد القوائم المالية وفق المعايير السعودية",
    description: "خطوات عملية لإعداد قوائم مالية متوافقة مع متطلبات هيئة الزكاة والضريبة والجمارك السعودية.",
    category: "قوائم مالية",
    author: "أ. سارة العتيبي",
    readTime: "8 دقائق",
    views: "1.8K",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop",
    date: "12 مارس 2024",
  },
  {
    id: 3,
    title: "أساسيات محاسبة التكاليف للمبتدئين",
    description: "مقدمة شاملة في محاسبة التكاليف وطرق حساب تكلفة المنتجات والخدمات بطرق علمية صحيحة.",
    category: "محاسبة التكاليف",
    author: "أ. خالد الشمري",
    readTime: "10 دقائق",
    views: "3.2K",
    image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?w=600&h=400&fit=crop",
    date: "10 مارس 2024",
  },
  {
    id: 4,
    title: "التخطيط الضريبي للشركات الصغيرة والمتوسطة",
    description: "استراتيجيات فعالة لتقليل العبء الضريبي بطرق قانونية ومعتمدة من الجهات الرسمية.",
    category: "الضرائب",
    author: "أ. منى الحربي",
    readTime: "15 دقيقة",
    views: "2.1K",
    image: "https://images.unsplash.com/photo-1554224155-3a58922a22c3?w=600&h=400&fit=crop",
    date: "8 مارس 2024",
  },
  {
    id: 5,
    title: "إجراءات المراجعة الداخلية الفعالة",
    description: "كيف تقوم بمراجعة داخلية شاملة وفعالة تضمن سلامة العمليات المالية في مؤسستك.",
    category: "المراجعة والتدقيق",
    author: "د. فهد العمري",
    readTime: "18 دقيقة",
    views: "1.5K",
    image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=600&h=400&fit=crop",
    date: "5 مارس 2024",
  },
  {
    id: 6,
    title: "تحليل القوائم المالية باستخدام النسب المالية",
    description: "دليل عملي لفهم وتحليل القوائم المالية باستخدام مختلف النسب المالية.",
    category: "تحليل مالي",
    author: "أ. نورة السالم",
    readTime: "14 دقيقة",
    views: "2.8K",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
    date: "1 مارس 2024",
  },
]

export default function ArticlesPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="border-b border-border bg-muted/30 py-12 lg:py-20">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <BookOpen className="h-4 w-4" />
                مقالات محاسبية
              </div>
              <h1 className="mb-4 text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl text-balance">
                المقالات المحاسبية المتخصصة
              </h1>
              <p className="text-lg text-muted-foreground">
                اكتشف أحدث المقالات والأبحاث في مجال المحاسبة والمراجعة
              </p>
            </div>

            {/* Search */}
            <div className="mx-auto mt-8 max-w-2xl">
              <div className="relative">
                <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input 
                  placeholder="ابحث في المقالات..." 
                  className="h-12 pr-12 text-base"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Articles */}
        <section className="py-12 lg:py-16">
          <div className="container mx-auto px-4 lg:px-8">
            {/* Categories */}
            <div className="mb-8 flex flex-wrap gap-2">
              {categories.map((category, index) => (
                <Button 
                  key={category} 
                  variant={index === 0 ? "default" : "outline"} 
                  size="sm"
                  className="rounded-full"
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Articles Grid */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {articles.map((article) => (
                <Card 
                  key={article.id} 
                  className="group overflow-hidden border-border/50 transition-all hover:border-primary/30 hover:shadow-lg cursor-pointer"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <Badge className="absolute top-3 right-3 bg-primary/90 hover:bg-primary">
                      {article.category}
                    </Badge>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="mb-2 text-sm text-muted-foreground">{article.date}</div>
                    <CardTitle className="line-clamp-2 text-lg group-hover:text-primary transition-colors">
                      {article.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {article.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        <span>{article.author}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{article.readTime}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          <span>{article.views}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More */}
            <div className="mt-12 text-center">
              <Button variant="outline" size="lg">
                تحميل المزيد من المقالات
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

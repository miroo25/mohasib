import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { 
  Search, 
  MapPin, 
  Clock, 
  Banknote, 
  Building2, 
  Briefcase,
  ArrowLeft,
  Filter,
  SlidersHorizontal
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const filters = {
  types: ["الكل", "دوام كامل", "دوام جزئي", "عن بعد", "تدريب تعاوني"],
  locations: ["الكل", "الرياض", "جدة", "الدمام", "مكة المكرمة", "المدينة المنورة"],
  experience: ["الكل", "حديث التخرج", "1-3 سنوات", "3-5 سنوات", "5+ سنوات"],
}

const jobs = [
  {
    id: 1,
    title: "محاسب أول",
    company: "شركة الراجحي للاستثمار",
    logo: "https://ui-avatars.com/api/?name=الراجحي&background=1e40af&color=fff&size=64",
    location: "الرياض، السعودية",
    type: "دوام كامل",
    salary: "15,000 - 20,000 ر.س",
    posted: "منذ يومين",
    urgent: true,
    experience: "3-5 سنوات",
    description: "نبحث عن محاسب أول للانضمام لفريقنا المالي. يجب أن يكون لديه خبرة في إعداد القوائم المالية والتقارير الضريبية.",
    requirements: ["بكالوريوس محاسبة", "خبرة 3 سنوات", "إجادة Excel", "معرفة بـ SAP"],
  },
  {
    id: 2,
    title: "مدير مالي",
    company: "مجموعة سابك",
    logo: "https://ui-avatars.com/api/?name=سابك&background=059669&color=fff&size=64",
    location: "جدة، السعودية",
    type: "دوام كامل",
    salary: "25,000 - 35,000 ر.س",
    posted: "منذ 3 أيام",
    urgent: false,
    experience: "5+ سنوات",
    description: "مطلوب مدير مالي لقيادة القسم المالي وإدارة فريق من المحاسبين.",
    requirements: ["ماجستير محاسبة/مالية", "CPA أو CMA", "خبرة 7 سنوات", "قيادة فرق"],
  },
  {
    id: 3,
    title: "محاسب تكاليف",
    company: "شركة المراعي",
    logo: "https://ui-avatars.com/api/?name=المراعي&background=7c3aed&color=fff&size=64",
    location: "الدمام، السعودية",
    type: "دوام كامل",
    salary: "12,000 - 16,000 ر.س",
    posted: "منذ أسبوع",
    urgent: false,
    experience: "1-3 سنوات",
    description: "مطلوب محاسب تكاليف للعمل في قسم التصنيع.",
    requirements: ["بكالوريوس محاسبة", "خبرة في محاسبة التكاليف", "معرفة بـ ERP"],
  },
  {
    id: 4,
    title: "مراجع داخلي",
    company: "بنك الإنماء",
    logo: "https://ui-avatars.com/api/?name=الإنماء&background=dc2626&color=fff&size=64",
    location: "الرياض، السعودية",
    type: "دوام كامل",
    salary: "18,000 - 22,000 ر.س",
    posted: "منذ 5 أيام",
    urgent: true,
    experience: "3-5 سنوات",
    description: "نبحث عن مراجع داخلي لتنفيذ عمليات المراجعة الداخلية.",
    requirements: ["CIA مفضل", "خبرة في البنوك", "معرفة بالمعايير الدولية"],
  },
  {
    id: 5,
    title: "محاسب - عمل عن بعد",
    company: "شركة تقنية ناشئة",
    logo: "https://ui-avatars.com/api/?name=تقنية&background=0891b2&color=fff&size=64",
    location: "عن بعد",
    type: "عن بعد",
    salary: "10,000 - 14,000 ر.س",
    posted: "منذ يوم",
    urgent: false,
    experience: "1-3 سنوات",
    description: "فرصة للعمل عن بعد كمحاسب في شركة تقنية ناشئة.",
    requirements: ["بكالوريوس محاسبة", "خبرة سنة", "إجادة برامج المحاسبة السحابية"],
  },
  {
    id: 6,
    title: "محاسب حديث التخرج",
    company: "مكتب محاسبة معتمد",
    logo: "https://ui-avatars.com/api/?name=مكتب&background=ea580c&color=fff&size=64",
    location: "الرياض، السعودية",
    type: "تدريب تعاوني",
    salary: "6,000 - 8,000 ر.س",
    posted: "منذ 3 أيام",
    urgent: false,
    experience: "حديث التخرج",
    description: "فرصة تدريبية ممتازة للخريجين الجدد في مكتب محاسبة معتمد.",
    requirements: ["بكالوريوس محاسبة", "معدل جيد جداً", "رغبة في التعلم"],
  },
]

export default function JobsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="border-b border-border bg-muted/30 py-12 lg:py-20">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <Briefcase className="h-4 w-4" />
                وظائف محاسبية
              </div>
              <h1 className="mb-4 text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl text-balance">
                اعثر على وظيفتك المثالية
              </h1>
              <p className="text-lg text-muted-foreground">
                أكثر من 150 فرصة عمل في أفضل الشركات والمؤسسات
              </p>
            </div>

            {/* Search */}
            <div className="mx-auto mt-8 max-w-4xl">
              <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-4 shadow-sm md:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <Input 
                    placeholder="المسمى الوظيفي أو الشركة..." 
                    className="h-12 pr-12 text-base border-0 bg-transparent"
                  />
                </div>
                <div className="flex gap-2">
                  <Select>
                    <SelectTrigger className="h-12 w-40">
                      <SelectValue placeholder="الموقع" />
                    </SelectTrigger>
                    <SelectContent>
                      {filters.locations.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button size="lg" className="h-12 gap-2">
                    <Search className="h-4 w-4" />
                    بحث
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Jobs List */}
        <section className="py-12 lg:py-16">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex flex-col gap-8 lg:flex-row">
              {/* Sidebar Filters */}
              <aside className="w-full shrink-0 lg:w-64">
                <div className="sticky top-24 rounded-xl border border-border bg-card p-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="font-semibold">تصفية النتائج</h3>
                    <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
                  </div>

                  {/* Job Type */}
                  <div className="mb-6">
                    <h4 className="mb-3 text-sm font-medium text-muted-foreground">نوع الوظيفة</h4>
                    <div className="space-y-2">
                      {filters.types.map((type) => (
                        <label key={type} className="flex cursor-pointer items-center gap-2">
                          <input type="checkbox" className="rounded border-border" />
                          <span className="text-sm">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Experience */}
                  <div className="mb-6">
                    <h4 className="mb-3 text-sm font-medium text-muted-foreground">الخبرة</h4>
                    <div className="space-y-2">
                      {filters.experience.map((exp) => (
                        <label key={exp} className="flex cursor-pointer items-center gap-2">
                          <input type="checkbox" className="rounded border-border" />
                          <span className="text-sm">{exp}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <Button variant="outline" className="w-full">
                    إعادة تعيين
                  </Button>
                </div>
              </aside>

              {/* Jobs */}
              <div className="flex-1">
                <div className="mb-6 flex items-center justify-between">
                  <p className="text-muted-foreground">
                    عرض <span className="font-semibold text-foreground">{jobs.length}</span> وظيفة
                  </p>
                  <Select defaultValue="newest">
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">الأحدث</SelectItem>
                      <SelectItem value="salary-high">الراتب (الأعلى)</SelectItem>
                      <SelectItem value="salary-low">الراتب (الأقل)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  {jobs.map((job) => (
                    <Card 
                      key={job.id} 
                      className="group overflow-hidden border-border/50 transition-all hover:border-primary/30 hover:shadow-lg"
                    >
                      <CardContent className="p-6">
                        <div className="flex flex-col gap-4 sm:flex-row">
                          {/* Company Logo */}
                          <img
                            src={job.logo}
                            alt={job.company}
                            className="h-16 w-16 shrink-0 rounded-xl object-cover"
                          />

                          {/* Job Info */}
                          <div className="flex-1">
                            <div className="mb-2 flex flex-wrap items-center gap-2">
                              <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                                {job.title}
                              </h3>
                              {job.urgent && (
                                <Badge variant="destructive" className="text-xs">
                                  عاجل
                                </Badge>
                              )}
                              <Badge variant="secondary" className="text-xs">
                                {job.type}
                              </Badge>
                            </div>

                            <p className="mb-3 text-sm text-muted-foreground line-clamp-2">
                              {job.description}
                            </p>

                            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                <span>{job.company}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                <span>{job.location}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Banknote className="h-4 w-4" />
                                <span>{job.salary}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                <span>{job.posted}</span>
                              </div>
                            </div>

                            {/* Requirements */}
                            <div className="mt-3 flex flex-wrap gap-2">
                              {job.requirements.slice(0, 3).map((req) => (
                                <Badge key={req} variant="outline" className="text-xs">
                                  {req}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          {/* Apply Button */}
                          <div className="flex shrink-0 flex-col gap-2 sm:items-end">
                            <Button className="gap-2">
                              تقدم الآن
                              <ArrowLeft className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              حفظ الوظيفة
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Load More */}
                <div className="mt-8 text-center">
                  <Button variant="outline" size="lg">
                    تحميل المزيد من الوظائف
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

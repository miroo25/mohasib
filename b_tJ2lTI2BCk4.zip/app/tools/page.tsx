"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { 
  Search, 
  Calculator, 
  FileSpreadsheet, 
  PieChart, 
  Receipt, 
  TrendingUp, 
  Percent,
  Building,
  CreditCard,
  AppWindow,
  ArrowLeft,
  Star,
  Users,
  BarChart3,
  Wallet,
  FileText,
  Clock
} from "lucide-react"
import Link from "next/link"

const categories = [
  { name: "الكل", count: 25 },
  { name: "الضرائب", count: 6 },
  { name: "الأصول", count: 4 },
  { name: "الرواتب", count: 5 },
  { name: "التحليل", count: 4 },
  { name: "القروض", count: 3 },
  { name: "الزكاة", count: 3 },
]

const tools = [
  {
    id: 1,
    name: "حاسبة ضريبة القيمة المضافة",
    description: "احسب ضريبة القيمة المضافة بسهولة ودقة. يدعم جميع نسب الضريبة المعتمدة.",
    icon: Percent,
    category: "الضرائب",
    href: "/tools/vat-calculator",
    popular: true,
    users: "15K+",
    rating: 4.9,
    color: "bg-blue-500/10 text-blue-600",
  },
  {
    id: 2,
    name: "جدول الإهلاك",
    description: "إنشاء جداول إهلاك الأصول الثابتة بجميع الطرق المحاسبية المعتمدة.",
    icon: TrendingUp,
    category: "الأصول",
    href: "/tools/depreciation",
    popular: true,
    users: "12K+",
    rating: 4.8,
    color: "bg-green-500/10 text-green-600",
  },
  {
    id: 3,
    name: "حاسبة نهاية الخدمة",
    description: "احسب مكافأة نهاية الخدمة حسب نظام العمل السعودي والخليجي.",
    icon: Receipt,
    category: "الرواتب",
    href: "/tools/end-of-service",
    popular: false,
    users: "8K+",
    rating: 4.7,
    color: "bg-orange-500/10 text-orange-600",
  },
  {
    id: 4,
    name: "تحليل النسب المالية",
    description: "تحليل شامل للنسب المالية للشركات مع تقارير احترافية.",
    icon: PieChart,
    category: "التحليل",
    href: "/tools/financial-ratios",
    popular: true,
    users: "10K+",
    rating: 4.9,
    color: "bg-purple-500/10 text-purple-600",
  },
  {
    id: 5,
    name: "حاسبة القروض",
    description: "احسب الأقساط الشهرية ومجموع الفوائد لأي قرض.",
    icon: CreditCard,
    category: "القروض",
    href: "/tools/loan-calculator",
    popular: false,
    users: "6K+",
    rating: 4.6,
    color: "bg-red-500/10 text-red-600",
  },
  {
    id: 6,
    name: "حاسبة الزكاة",
    description: "احسب زكاة المال والتجارة والأسهم بطريقة صحيحة شرعياً.",
    icon: Building,
    category: "الزكاة",
    href: "/tools/zakat-calculator",
    popular: true,
    users: "20K+",
    rating: 5.0,
    color: "bg-teal-500/10 text-teal-600",
  },
  {
    id: 7,
    name: "حاسبة الرواتب",
    description: "احسب صافي الراتب بعد الخصومات والتأمينات.",
    icon: Wallet,
    category: "الرواتب",
    href: "/tools/salary-calculator",
    popular: false,
    users: "9K+",
    rating: 4.7,
    color: "bg-indigo-500/10 text-indigo-600",
  },
  {
    id: 8,
    name: "محول العملات",
    description: "حول بين العملات بأسعار الصرف المحدثة لحظياً.",
    icon: BarChart3,
    category: "التحليل",
    href: "/tools/currency-converter",
    popular: false,
    users: "7K+",
    rating: 4.5,
    color: "bg-cyan-500/10 text-cyan-600",
  },
  {
    id: 9,
    name: "مولد الفواتير",
    description: "أنشئ فواتير احترافية متوافقة مع هيئة الزكاة والضريبة.",
    icon: FileText,
    category: "الضرائب",
    href: "/tools/invoice-generator",
    popular: true,
    users: "14K+",
    rating: 4.8,
    color: "bg-amber-500/10 text-amber-600",
  },
]

export default function ToolsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="border-b border-border bg-muted/30 py-12 lg:py-20">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <AppWindow className="h-4 w-4" />
                أدوات محاسبية
              </div>
              <h1 className="mb-4 text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl text-balance">
                التطبيقات المحاسبية
              </h1>
              <p className="text-lg text-muted-foreground">
                أكثر من 25 أداة وتطبيق محاسبي احترافي لمساعدتك في عملك
              </p>
            </div>

            {/* Search */}
            <div className="mx-auto mt-8 max-w-2xl">
              <div className="relative">
                <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input 
                  placeholder="ابحث عن أداة..." 
                  className="h-12 pr-12 text-base"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Tools */}
        <section className="py-12 lg:py-16">
          <div className="container mx-auto px-4 lg:px-8">
            {/* Categories */}
            <div className="mb-8 flex flex-wrap gap-2">
              {categories.map((category, index) => (
                <Button 
                  key={category.name} 
                  variant={index === 0 ? "default" : "outline"} 
                  size="sm"
                  className="rounded-full gap-2"
                >
                  {category.name}
                  <Badge variant="secondary" className="text-xs">
                    {category.count}
                  </Badge>
                </Button>
              ))}
            </div>

            {/* Tools Grid */}
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {tools.map((tool) => (
                <Link key={tool.id} href={tool.href}>
                  <Card className="group h-full cursor-pointer border-border/50 transition-all hover:border-primary/30 hover:shadow-lg">
                    <CardHeader className="pb-4">
                      <div className="flex items-start justify-between">
                        <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${tool.color} transition-transform group-hover:scale-110`}>
                          <tool.icon className="h-7 w-7" />
                        </div>
                        {tool.popular && (
                          <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
                            شائع
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="mt-4 text-lg group-hover:text-primary transition-colors">
                        {tool.name}
                      </CardTitle>
                      <CardDescription className="line-clamp-2">
                        {tool.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            <span>{tool.users}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                            <span>{tool.rating}</span>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {tool.category}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {/* Coming Soon */}
            <div className="mt-16 rounded-2xl border border-dashed border-border bg-muted/30 p-12 text-center">
              <Clock className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 text-xl font-semibold">المزيد من الأدوات قريباً</h3>
              <p className="mb-6 text-muted-foreground">
                نعمل على تطوير المزيد من الأدوات المحاسبية لمساعدتك في عملك
              </p>
              <Button variant="outline">
                اقترح أداة جديدة
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { 
  Percent, 
  Calculator, 
  ArrowRight, 
  Copy, 
  Check,
  RefreshCw,
  Info
} from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const vatRates = [
  { value: "15", label: "15% - السعودية والإمارات" },
  { value: "5", label: "5% - البحرين والكويت" },
  { value: "10", label: "10% - مصر" },
  { value: "16", label: "16% - الأردن" },
  { value: "20", label: "20% - المغرب" },
]

export default function VATCalculatorPage() {
  const [amount, setAmount] = useState<string>("")
  const [vatRate, setVatRate] = useState<string>("15")
  const [calculationType, setCalculationType] = useState<string>("add")
  const [copied, setCopied] = useState<boolean>(false)

  const numericAmount = parseFloat(amount) || 0
  const rate = parseFloat(vatRate) / 100

  // Calculations
  const vatAmount = calculationType === "add" 
    ? numericAmount * rate 
    : numericAmount - (numericAmount / (1 + rate))
  
  const totalAmount = calculationType === "add" 
    ? numericAmount + vatAmount 
    : numericAmount
  
  const priceBeforeVat = calculationType === "add" 
    ? numericAmount 
    : numericAmount / (1 + rate)

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ar-SA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num)
  }

  const handleCopy = () => {
    const text = `
المبلغ قبل الضريبة: ${formatNumber(priceBeforeVat)} ر.س
ضريبة القيمة المضافة (${vatRate}%): ${formatNumber(vatAmount)} ر.س
المبلغ الإجمالي: ${formatNumber(totalAmount)} ر.س
    `.trim()
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleReset = () => {
    setAmount("")
    setVatRate("15")
    setCalculationType("add")
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="py-12 lg:py-16">
        <div className="container mx-auto px-4 lg:px-8">
          {/* Breadcrumb */}
          <div className="mb-8 flex items-center gap-2 text-sm text-muted-foreground">
            <a href="/tools" className="hover:text-foreground">التطبيقات</a>
            <ArrowRight className="h-4 w-4 rotate-180" />
            <span className="text-foreground">حاسبة ضريبة القيمة المضافة</span>
          </div>

          <div className="grid gap-8 lg:grid-cols-2">
            {/* Calculator */}
            <div>
              <Card className="border-border/50">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Percent className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle>حاسبة ضريبة القيمة المضافة</CardTitle>
                      <CardDescription>احسب الضريبة بسهولة ودقة</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Calculation Type */}
                  <Tabs value={calculationType} onValueChange={setCalculationType}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="add">إضافة الضريبة</TabsTrigger>
                      <TabsTrigger value="extract">استخراج الضريبة</TabsTrigger>
                    </TabsList>
                  </Tabs>

                  {/* Amount Input */}
                  <div className="space-y-2">
                    <Label htmlFor="amount">
                      {calculationType === "add" ? "المبلغ قبل الضريبة" : "المبلغ شامل الضريبة"}
                    </Label>
                    <div className="relative">
                      <Input
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="h-12 text-lg pr-4 pl-12"
                      />
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                        ر.س
                      </span>
                    </div>
                  </div>

                  {/* VAT Rate */}
                  <div className="space-y-2">
                    <Label>نسبة ضريبة القيمة المضافة</Label>
                    <Select value={vatRate} onValueChange={setVatRate}>
                      <SelectTrigger className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {vatRates.map((rate) => (
                          <SelectItem key={rate.value} value={rate.value}>
                            {rate.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button variant="outline" className="gap-2" onClick={handleReset}>
                      <RefreshCw className="h-4 w-4" />
                      إعادة تعيين
                    </Button>
                    <Button variant="outline" className="gap-2" onClick={handleCopy}>
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied ? "تم النسخ" : "نسخ النتائج"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Info Card */}
              <Card className="mt-6 border-border/50 bg-muted/30">
                <CardContent className="flex items-start gap-3 p-4">
                  <Info className="h-5 w-5 shrink-0 text-primary mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-2">
                      <strong>إضافة الضريبة:</strong> عندما تريد معرفة السعر النهائي شامل الضريبة.
                    </p>
                    <p>
                      <strong>استخراج الضريبة:</strong> عندما تريد معرفة السعر الأصلي ومبلغ الضريبة من السعر الإجمالي.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Results */}
            <div>
              <Card className="sticky top-24 border-primary/20 bg-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-primary" />
                    نتائج الحساب
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Price Before VAT */}
                  <div className="rounded-xl border border-border bg-card p-4">
                    <div className="mb-1 text-sm text-muted-foreground">المبلغ قبل الضريبة</div>
                    <div className="text-2xl font-bold text-foreground">
                      {formatNumber(priceBeforeVat)} <span className="text-lg font-normal">ر.س</span>
                    </div>
                  </div>

                  {/* VAT Amount */}
                  <div className="rounded-xl border border-border bg-card p-4">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">ضريبة القيمة المضافة</span>
                      <Badge variant="secondary">{vatRate}%</Badge>
                    </div>
                    <div className="text-2xl font-bold text-primary">
                      {formatNumber(vatAmount)} <span className="text-lg font-normal">ر.س</span>
                    </div>
                  </div>

                  {/* Total */}
                  <div className="rounded-xl border-2 border-primary bg-primary/10 p-4">
                    <div className="mb-1 text-sm text-muted-foreground">المبلغ الإجمالي</div>
                    <div className="text-3xl font-bold text-primary">
                      {formatNumber(totalAmount)} <span className="text-xl font-normal">ر.س</span>
                    </div>
                  </div>

                  {/* Formula */}
                  <div className="rounded-xl border border-border bg-card p-4">
                    <div className="mb-2 text-sm font-medium text-muted-foreground">المعادلة المستخدمة:</div>
                    <code className="text-sm text-foreground" dir="ltr">
                      {calculationType === "add" 
                        ? `${formatNumber(numericAmount)} × ${vatRate}% = ${formatNumber(vatAmount)}`
                        : `${formatNumber(numericAmount)} ÷ 1.${vatRate} = ${formatNumber(priceBeforeVat)}`
                      }
                    </code>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Related Tools */}
          <div className="mt-16">
            <h2 className="mb-6 text-2xl font-bold">أدوات ذات صلة</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { name: "حاسبة الزكاة", href: "/tools/zakat-calculator", icon: "🕌" },
                { name: "مولد الفواتير", href: "/tools/invoice-generator", icon: "📄" },
                { name: "حاسبة القروض", href: "/tools/loan-calculator", icon: "💳" },
              ].map((tool) => (
                <a key={tool.name} href={tool.href}>
                  <Card className="group cursor-pointer border-border/50 transition-all hover:border-primary/30 hover:shadow-lg">
                    <CardContent className="flex items-center gap-4 p-4">
                      <div className="text-3xl">{tool.icon}</div>
                      <div className="font-medium group-hover:text-primary transition-colors">
                        {tool.name}
                      </div>
                    </CardContent>
                  </Card>
                </a>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

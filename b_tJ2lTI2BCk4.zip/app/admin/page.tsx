import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { FileText, Briefcase, Wrench, Eye, Plus, TrendingUp } from 'lucide-react'

export default async function AdminDashboard() {
  const supabase = await createClient()

  // Fetch counts
  const [articlesResult, jobsResult, toolsResult] = await Promise.all([
    supabase.from('articles').select('*', { count: 'exact', head: true }),
    supabase.from('jobs').select('*', { count: 'exact', head: true }),
    supabase.from('tools').select('*', { count: 'exact', head: true }),
  ])

  const stats = [
    {
      title: 'المقالات',
      value: articlesResult.count || 0,
      icon: FileText,
      href: '/admin/articles',
      color: 'bg-blue-500/10 text-blue-600',
    },
    {
      title: 'الوظائف',
      value: jobsResult.count || 0,
      icon: Briefcase,
      href: '/admin/jobs',
      color: 'bg-green-500/10 text-green-600',
    },
    {
      title: 'الأدوات',
      value: toolsResult.count || 0,
      icon: Wrench,
      href: '/admin/tools',
      color: 'bg-orange-500/10 text-orange-600',
    },
  ]

  // Fetch recent items
  const [recentArticles, recentJobs] = await Promise.all([
    supabase
      .from('articles')
      .select('id, title, is_published, created_at')
      .order('created_at', { ascending: false })
      .limit(5),
    supabase
      .from('jobs')
      .select('id, title, company, is_active, created_at')
      .order('created_at', { ascending: false })
      .limit(5),
  ])

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-muted-foreground mt-1">مرحباً بك في لوحة تحكم منصة محاسبون</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-3">
        {stats.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="text-3xl font-bold text-foreground mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-lg ${stat.color}`}>
                    <stat.icon className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>إجراءات سريعة</CardTitle>
          <CardDescription>أضف محتوى جديد للمنصة</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Button asChild>
            <Link href="/admin/articles/new">
              <Plus className="w-4 h-4 ml-2" />
              مقال جديد
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/admin/jobs/new">
              <Plus className="w-4 h-4 ml-2" />
              وظيفة جديدة
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/admin/tools/new">
              <Plus className="w-4 h-4 ml-2" />
              أداة جديدة
            </Link>
          </Button>
        </CardContent>
      </Card>

      {/* Recent Content */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Articles */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">أحدث المقالات</CardTitle>
              <CardDescription>آخر المقالات المضافة</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/articles">عرض الكل</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {recentArticles.data && recentArticles.data.length > 0 ? (
              <div className="space-y-3">
                {recentArticles.data.map((article) => (
                  <div
                    key={article.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{article.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(article.created_at).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        article.is_published
                          ? 'bg-green-500/10 text-green-600'
                          : 'bg-yellow-500/10 text-yellow-600'
                      }`}
                    >
                      {article.is_published ? 'منشور' : 'مسودة'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">لا توجد مقالات بعد</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Jobs */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">أحدث الوظائف</CardTitle>
              <CardDescription>آخر الوظائف المضافة</CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/jobs">عرض الكل</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {recentJobs.data && recentJobs.data.length > 0 ? (
              <div className="space-y-3">
                {recentJobs.data.map((job) => (
                  <div
                    key={job.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{job.title}</p>
                      <p className="text-xs text-muted-foreground">{job.company}</p>
                    </div>
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        job.is_active
                          ? 'bg-green-500/10 text-green-600'
                          : 'bg-red-500/10 text-red-600'
                      }`}
                    >
                      {job.is_active ? 'نشط' : 'متوقف'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">لا توجد وظائف بعد</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

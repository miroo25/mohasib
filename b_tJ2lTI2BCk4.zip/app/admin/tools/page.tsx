import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Edit, ExternalLink } from 'lucide-react'
import { DeleteToolButton } from '@/components/admin/delete-tool-button'

export default async function AdminToolsPage() {
  const supabase = await createClient()
  
  const { data: tools } = await supabase
    .from('tools')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">الأدوات</h1>
          <p className="text-muted-foreground mt-1">إدارة التطبيقات المحاسبية</p>
        </div>
        <Button asChild>
          <Link href="/admin/tools/new">
            <Plus className="w-4 h-4 ml-2" />
            أداة جديدة
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>جميع الأدوات</CardTitle>
          <CardDescription>
            {tools?.length || 0} أداة
          </CardDescription>
        </CardHeader>
        <CardContent>
          {tools && tools.length > 0 ? (
            <div className="divide-y divide-border">
              {tools.map((tool) => (
                <div key={tool.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate">{tool.name}</h3>
                    <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                      <span>{tool.category}</span>
                      <span>•</span>
                      <span>{tool.usage_count} استخدام</span>
                      <span>•</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs ${
                          tool.is_active
                            ? 'bg-green-500/10 text-green-600'
                            : 'bg-red-500/10 text-red-600'
                        }`}
                      >
                        {tool.is_active ? 'نشط' : 'متوقف'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/tools/${tool.slug}`} target="_blank">
                        <ExternalLink className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/admin/tools/${tool.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <DeleteToolButton id={tool.id} name={tool.name} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">لا توجد أدوات بعد</p>
              <Button asChild>
                <Link href="/admin/tools/new">
                  <Plus className="w-4 h-4 ml-2" />
                  أضف أول أداة
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

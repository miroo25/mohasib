import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Edit, Eye, Trash2 } from 'lucide-react'
import { DeleteJobButton } from '@/components/admin/delete-job-button'

export default async function AdminJobsPage() {
  const supabase = await createClient()
  
  const { data: jobs } = await supabase
    .from('jobs')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">الوظائف</h1>
          <p className="text-muted-foreground mt-1">إدارة الوظائف المحاسبية</p>
        </div>
        <Button asChild>
          <Link href="/admin/jobs/new">
            <Plus className="w-4 h-4 ml-2" />
            وظيفة جديدة
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>جميع الوظائف</CardTitle>
          <CardDescription>
            {jobs?.length || 0} وظيفة
          </CardDescription>
        </CardHeader>
        <CardContent>
          {jobs && jobs.length > 0 ? (
            <div className="divide-y divide-border">
              {jobs.map((job) => (
                <div key={job.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate">{job.title}</h3>
                    <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                      <span>{job.company}</span>
                      <span>•</span>
                      <span>{job.location}</span>
                      <span>•</span>
                      <span>{job.job_type}</span>
                      <span>•</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs ${
                          job.is_active
                            ? 'bg-green-500/10 text-green-600'
                            : 'bg-red-500/10 text-red-600'
                        }`}
                      >
                        {job.is_active ? 'نشط' : 'متوقف'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/admin/jobs/${job.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <DeleteJobButton id={job.id} title={job.title} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">لا توجد وظائف بعد</p>
              <Button asChild>
                <Link href="/admin/jobs/new">
                  <Plus className="w-4 h-4 ml-2" />
                  أضف أول وظيفة
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

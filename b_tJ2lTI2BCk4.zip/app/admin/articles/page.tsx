import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Edit, Eye, Trash2 } from 'lucide-react'
import { DeleteArticleButton } from '@/components/admin/delete-article-button'

export default async function AdminArticlesPage() {
  const supabase = await createClient()
  
  const { data: articles } = await supabase
    .from('articles')
    .select('*')
    .order('created_at', { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">المقالات</h1>
          <p className="text-muted-foreground mt-1">إدارة المقالات المحاسبية</p>
        </div>
        <Button asChild>
          <Link href="/admin/articles/new">
            <Plus className="w-4 h-4 ml-2" />
            مقال جديد
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>جميع المقالات</CardTitle>
          <CardDescription>
            {articles?.length || 0} مقال
          </CardDescription>
        </CardHeader>
        <CardContent>
          {articles && articles.length > 0 ? (
            <div className="divide-y divide-border">
              {articles.map((article) => (
                <div key={article.id} className="py-4 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate">{article.title}</h3>
                    <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                      <span>{article.category}</span>
                      <span>•</span>
                      <span>{new Date(article.created_at).toLocaleDateString('ar-SA')}</span>
                      <span>•</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs ${
                          article.is_published
                            ? 'bg-green-500/10 text-green-600'
                            : 'bg-yellow-500/10 text-yellow-600'
                        }`}
                      >
                        {article.is_published ? 'منشور' : 'مسودة'}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/articles/${article.slug}`} target="_blank">
                        <Eye className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/admin/articles/${article.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <DeleteArticleButton id={article.id} title={article.title} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">لا توجد مقالات بعد</p>
              <Button asChild>
                <Link href="/admin/articles/new">
                  <Plus className="w-4 h-4 ml-2" />
                  أضف أول مقال
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ServicesSection } from "@/components/services-section"
import { ArticlesPreview } from "@/components/articles-preview"
import { JobsPreview } from "@/components/jobs-preview"
import { ToolsPreview } from "@/components/tools-preview"
import { CTASection } from "@/components/cta-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <ServicesSection />
        <ArticlesPreview />
        <JobsPreview />
        <ToolsPreview />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
